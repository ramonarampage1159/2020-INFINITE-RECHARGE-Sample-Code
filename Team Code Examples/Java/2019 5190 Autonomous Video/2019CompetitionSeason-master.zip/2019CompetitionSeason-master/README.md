# Competition Season 2019

[![Build Status](https://dev.azure.com/frc5190/Robot%20Code/_apis/build/status/2019%20Competition%20Code)](https://dev.azure.com/frc5190/Robot%20Code/_build/latest?definitionId=4)

Welcome to the repository for our 2019 code! If you are contributing to the robot code this season, please make sure you follow these conventions:
 * Official Kotlin Style in IntelliJ IDEA
 * Constants are in `kConstant` form.
 * Other instance variables are in `instanceVariable` form.
