/*
 * FRC Team 5190
 * Green Hope Falcons
 */

rootProject.name = "2019CompetitionSeason"

